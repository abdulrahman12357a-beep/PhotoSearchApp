# لا حاجة لقواعد proguard خاصة حالياً (minifyEnabled = false)

package com.example.photosearch.classifier

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import java.io.File
import java.nio.MappedByteBuffer

/**
 * تصنيف الصور بالكامل على الجهاز (on-device) دون أي اتصال بالإنترنت.
 *
 * الإعداد المطلوب قبل التشغيل (مرة واحدة فقط):
 * 1) ضع ملف النموذج المدرَّب مسبقاً باسم "model.tflite" داخل app/src/main/assets/
 *    (مثال جاهز وخفيف: MobileNetV2 المدرَّب على ImageNet، حجمه حوالي 14 ميجا)
 * 2) ضع ملف الفئات المقابل باسم "labels.txt" (سطر لكل فئة، 1000 سطر لـ ImageNet)
 *
 * هذان الملفان لا يمكن تحميلهما هنا لأن هذه البيئة لا تملك اتصال إنترنت،
 * لكن يمكن تحميلهما بسهولة من TensorFlow Hub أو TensorFlow examples الرسمية
 * وإسقاطهما داخل مجلد assets مباشرة من Android Studio.
 */
class ImageClassifier(context: Context) {

    private var interpreter: Interpreter? = null
    private var labels: List<String> = emptyList()
    private val inputSize = 224 // حجم الإدخال القياسي لـ MobileNet

    val isReady: Boolean get() = interpreter != null && labels.isNotEmpty()

    init {
        try {
            val model: MappedByteBuffer = FileUtil.loadMappedFile(context, "model.tflite")
            interpreter = Interpreter(model)
            labels = FileUtil.loadLabels(context, "labels.txt")
        } catch (e: Exception) {
            // النموذج غير موجود بعد داخل assets - التطبيق يعمل لكن بدون تصنيف
            // حتى يضيف المستخدم/المطوّر ملفي model.tflite و labels.txt
            interpreter = null
        }
    }

    /**
     * يرجع أفضل 5 تسميات مع درجة الثقة لكل صورة، مرتبة تنازلياً.
     */
    fun classify(imageFile: File): List<Pair<String, Float>> {
        val interp = interpreter ?: return emptyList()

        val bitmap = BitmapFactory.decodeFile(imageFile.absolutePath) ?: return emptyList()

        val imageProcessor = ImageProcessor.Builder()
            .add(ResizeOp(inputSize, inputSize, ResizeOp.ResizeMethod.BILINEAR))
            .build()

        var tensorImage = TensorImage(org.tensorflow.lite.DataType.UINT8)
        tensorImage.load(bitmap)
        tensorImage = imageProcessor.process(tensorImage)

        val outputSize = labels.size
        val output = Array(1) { ByteArray(outputSize) }

        interp.run(tensorImage.buffer, output)

        val scores = output[0].mapIndexed { index, byte ->
            val label = labels.getOrElse(index) { "unknown" }
            val confidence = (byte.toInt() and 0xFF) / 255f
            label to confidence
        }

        return scores.sortedByDescending { it.second }.take(5)
    }

    fun close() {
        interpreter?.close()
    }
}

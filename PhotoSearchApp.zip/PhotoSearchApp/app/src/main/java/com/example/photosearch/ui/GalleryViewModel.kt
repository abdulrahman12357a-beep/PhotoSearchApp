package com.example.photosearch.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.photosearch.data.AppDatabase
import com.example.photosearch.data.ImageTagEntity
import com.example.photosearch.indexer.PhotoIndexer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GalleryViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getInstance(application).imageTagDao()

    private val searchQuery = MutableStateFlow("")
    val query: StateFlow<String> = searchQuery

    val indexedCount: StateFlow<Int> = dao.getIndexedCount()
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.Eagerly, 0)

    val results: StateFlow<List<ImageTagEntity>> = searchQuery
        .combine(dao.getAll()) { q, all ->
            if (q.isBlank()) all
            else all.filter {
                it.category.contains(q, ignoreCase = true) ||
                    it.rawLabels.contains(q, ignoreCase = true)
            }
        }
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.Eagerly, emptyList())

    val categories: StateFlow<List<String>> = dao.getAllCategories()
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.Eagerly, emptyList())

    fun onSearchQueryChanged(newQuery: String) {
        searchQuery.value = newQuery
    }

    /** يبدأ فهرسة الصور بالخلفية (مرة أولى أو لالتقاط صور جديدة). */
    fun startIndexing() {
        val request = OneTimeWorkRequestBuilder<PhotoIndexer>().build()
        WorkManager.getInstance(getApplication()).enqueue(request)
    }

    /** يمسح كل البيانات المحلية (الفهرس بالكامل) بناءً على طلب المستخدم. */
    fun clearIndex() {
        viewModelScope.launch { dao.clearAll() }
    }
}

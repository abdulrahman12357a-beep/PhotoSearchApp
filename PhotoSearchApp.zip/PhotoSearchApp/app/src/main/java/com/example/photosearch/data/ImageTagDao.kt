package com.example.photosearch.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ImageTagDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(tag: ImageTagEntity)

    @Query("SELECT * FROM image_tags ORDER BY dateAdded DESC")
    fun getAll(): Flow<List<ImageTagEntity>>

    // بحث نصي: يطابق كلمة البحث مع الفئة العامة أو أي وسم خام مخزّن
    @Query(
        """
        SELECT * FROM image_tags
        WHERE category LIKE '%' || :query || '%'
           OR rawLabels LIKE '%' || :query || '%'
        ORDER BY confidence DESC
        """
    )
    fun search(query: String): Flow<List<ImageTagEntity>>

    @Query("SELECT DISTINCT category FROM image_tags ORDER BY category ASC")
    fun getAllCategories(): Flow<List<String>>

    @Query("SELECT * FROM image_tags WHERE category = :category ORDER BY dateAdded DESC")
    fun getByCategory(category: String): Flow<List<ImageTagEntity>>

    @Query("SELECT imageUri FROM image_tags")
    suspend fun getAllIndexedUris(): List<String>

    @Query("DELETE FROM image_tags")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM image_tags")
    fun getIndexedCount(): Flow<Int>
}

package com.example.photosearch.data

/**
 * النموذج المحلي (MobileNet المدرَّب على ImageNet) يرجع تسميات دقيقة جداً
 * (مثال: "golden retriever", "picture frame", "seashore"...).
 * هذا الكلاس يجمعها في فئات عامة يفهمها المستخدم وقت البحث.
 *
 * ملاحظة مهمة: هذه خريطة كلمات مفتاحية بسيطة تصلح كبداية سريعة تعمل بالكامل
 * دون إنترنت. إذا احتجت دقة أعلى لاحقاً، يمكن استبدال النموذج بنموذج
 * CLIP مصغّر (mobile) يفهم المفاهيم مباشرة بدل الاعتماد على قاموس كلمات.
 */
object CategoryMapper {

    private val categoryKeywords: Map<String, List<String>> = mapOf(
        "فن" to listOf(
            "picture frame", "canvas", "easel", "comic book", "abaya",
            "altar", "vault", "mosaic", "sculpture", "pottery", "vase",
            "stained glass", "obelisk", "totem pole"
        ),
        "حيوانات" to listOf(
            "dog", "cat", "bird", "horse", "cow", "sheep", "lion", "tiger",
            "bear", "elephant", "monkey", "fox", "wolf", "rabbit", "fish",
            "snake", "turtle", "retriever", "terrier", "hound", "spaniel",
            "poodle", "puppy", "kitten", "hen", "rooster", "goose", "duck"
        ),
        "طبيعة" to listOf(
            "mountain", "valley", "forest", "beach", "seashore", "lake",
            "river", "sky", "cliff", "volcano", "sunset", "sunrise",
            "flower", "tree", "plant", "field", "waterfall", "coral reef",
            "geyser", "iceberg", "desert"
        ),
        "طعام" to listOf(
            "pizza", "burger", "cake", "bread", "fruit", "vegetable",
            "plate", "soup", "sandwich", "ice cream", "pasta", "coffee",
            "wine", "banana", "orange", "strawberry", "pretzel"
        ),
        "مركبات" to listOf(
            "car", "truck", "bus", "train", "airplane", "bicycle",
            "motorcycle", "boat", "ship", "van", "jeep", "convertible",
            "sports car", "minivan"
        ),
        "مباني" to listOf(
            "building", "castle", "church", "mosque", "tower", "bridge",
            "palace", "house", "skyscraper", "monastery", "library",
            "dome", "lighthouse"
        ),
        "أشخاص" to listOf(
            "person", "man", "woman", "child", "groom", "bride",
            "military uniform", "suit", "academic gown"
        )
    )

    /**
     * يأخذ قائمة تسميات (مع درجات الثقة) من النموذج ويرجع أفضل فئة عامة تطابقها.
     * إذا لم تُطابق أي فئة، يرجع "أخرى".
     */
    fun categorize(labels: List<Pair<String, Float>>): Pair<String, Float> {
        for ((label, confidence) in labels) {
            val lower = label.lowercase()
            for ((category, keywords) in categoryKeywords) {
                if (keywords.any { lower.contains(it) }) {
                    return category to confidence
                }
            }
        }
        return "أخرى" to (labels.firstOrNull()?.second ?: 0f)
    }

    fun allCategories(): List<String> = categoryKeywords.keys.toList() + "أخرى"
}

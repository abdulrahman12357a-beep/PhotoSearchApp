package com.example.photosearch.indexer

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.photosearch.classifier.ImageClassifier
import com.example.photosearch.data.AppDatabase
import com.example.photosearch.data.CategoryMapper
import com.example.photosearch.data.ImageTagEntity
import java.io.File
import java.io.FileOutputStream

/**
 * يعمل بالخلفية دون تعطيل استخدام الجهاز (WorkManager).
 * يمسح مكتبة صور المستخدم عبر MediaStore، ويصنّف فقط الصور الجديدة
 * غير المفهرسة سابقاً، ويحفظ النتيجة في قاعدة البيانات المحلية.
 * لا يوجد أي إرسال بيانات لأي خادم خارجي في أي خطوة من هذه العملية.
 */
class PhotoIndexer(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val db = AppDatabase.getInstance(applicationContext)
        val dao = db.imageTagDao()
        val classifier = ImageClassifier(applicationContext)

        try {
            val alreadyIndexed = dao.getAllIndexedUris().toSet()

            val projection = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DATE_ADDED
            )

            applicationContext.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val dateAdded = cursor.getLong(dateCol)
                    val contentUri: Uri = Uri.withAppendedPath(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        id.toString()
                    )

                    if (alreadyIndexed.contains(contentUri.toString())) continue

                    val tempFile = copyToTempFile(contentUri) ?: continue
                    val labels = classifier.classify(tempFile)
                    tempFile.delete()

                    if (labels.isEmpty()) continue

                    val (category, confidence) = CategoryMapper.categorize(labels)

                    dao.upsert(
                        ImageTagEntity(
                            imageUri = contentUri.toString(),
                            dateAdded = dateAdded,
                            rawLabels = labels.joinToString(",") { it.first },
                            category = category,
                            confidence = confidence,
                            indexedAt = System.currentTimeMillis()
                        )
                    )
                }
            }
            return Result.success()
        } catch (e: Exception) {
            return Result.retry()
        } finally {
            classifier.close()
        }
    }

    private fun copyToTempFile(uri: Uri): File? {
        return try {
            val input = applicationContext.contentResolver.openInputStream(uri) ?: return null
            val temp = File.createTempFile("img_", ".tmp", applicationContext.cacheDir)
            FileOutputStream(temp).use { output -> input.copyTo(output) }
            input.close()
            temp
        } catch (e: Exception) {
            null
        }
    }
}

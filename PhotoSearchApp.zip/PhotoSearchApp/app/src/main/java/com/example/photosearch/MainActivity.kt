package com.example.photosearch

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import com.example.photosearch.ui.GalleryScreen
import com.example.photosearch.ui.GalleryViewModel

/**
 * التطبيق يطلب صلاحية واحدة فقط: قراءة الصور.
 * لا كاميرا، لا موقع، لا جهات اتصال، ولا صلاحية إنترنت في المانيفست أصلاً.
 */
class MainActivity : ComponentActivity() {

    private val viewModel: GalleryViewModel by viewModels()
    private var permissionGranted = mutableStateOf(false)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionGranted.value = granted
        if (granted) viewModel.startIndexing()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            Manifest.permission.READ_MEDIA_IMAGES
        else
            Manifest.permission.READ_EXTERNAL_STORAGE

        setContent {
            MaterialTheme {
                if (permissionGranted.value) {
                    GalleryScreen(viewModel)
                } else {
                    PermissionRequestScreen(
                        onRequestClick = { permissionLauncher.launch(permission) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PermissionRequestScreen(onRequestClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "🔒 التطبيق يعمل بالكامل دون إنترنت\nكل الفهرسة والبحث تتم محلياً على جهازك فقط",
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = onRequestClick) {
            Text("السماح بالوصول إلى الصور")
        }
    }
}

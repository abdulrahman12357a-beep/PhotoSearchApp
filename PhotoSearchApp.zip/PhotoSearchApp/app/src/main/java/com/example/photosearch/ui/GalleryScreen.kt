package com.example.photosearch.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryScreen(viewModel: GalleryViewModel) {
    val query by viewModel.query.collectAsState()
    val results by viewModel.results.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val indexedCount by viewModel.indexedCount.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("بحث الصور المحلي") },
                actions = {
                    IconButton(onClick = { viewModel.startIndexing() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث الفهرس")
                    }
                    IconButton(onClick = { viewModel.clearIndex() }) {
                        Icon(Icons.Default.Delete, contentDescription = "مسح كل البيانات المحلية")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { viewModel.onSearchQueryChanged(it) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                placeholder = { Text("ابحث... مثال: فن، حيوانات، طبيعة") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )

            Text(
                text = "عدد الصور المفهرسة محلياً: $indexedCount — كل شيء يبقى على جهازك فقط 🔒",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            if (categories.isNotEmpty()) {
                CategoryChipsRow(chipsCategories = categories, onCategoryClick = { viewModel.onSearchQueryChanged(it) })
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (results.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (indexedCount == 0)
                            "لا توجد صور مفهرسة بعد.\nاضغط زر التحديث بالأعلى لبدء الفهرسة المحلية."
                        else
                            "لا توجد نتائج مطابقة للبحث",
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    gridItems(results, key = { it.imageUri }) { item ->
                        AsyncImage(
                            model = item.imageUri,
                            contentDescription = item.category,
                            modifier = Modifier
                                .aspectRatio(1f)
                        )
                    }
                }
            }
        }
    }
}

/** شريط أفقي صغير من "الشرائح" (chips) لكل فئة مكتشفة، للانتقال السريع بين الألبومات الذكية. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CategoryChipsRow(chipsCategories: List<String>, onCategoryClick: (String) -> Unit) {
    androidx.compose.foundation.lazy.LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        rowItems(chipsCategories) { category ->
            AssistChip(
                onClick = { onCategoryClick(category) },
                label = { Text(category) }
            )
        }
    }
}

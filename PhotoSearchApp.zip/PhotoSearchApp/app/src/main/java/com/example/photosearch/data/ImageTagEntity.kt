package com.example.photosearch.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * يمثل صف واحد في قاعدة البيانات المحلية: صورة واحدة + التصنيفات (tags)
 * التي استنتجها النموذج المحلي منها + التصنيف العام (فئة) للألبوم الذكي.
 *
 * كل شيء هنا يبقى داخل الجهاز فقط (Room -> SQLite محلي)، لا مزامنة سحابية.
 */
@Entity(tableName = "image_tags")
data class ImageTagEntity(
    @PrimaryKey val imageUri: String,
    val dateAdded: Long,
    val rawLabels: String,      // كل الأوسمة الخام مفصولة بفواصل (نتيجة النموذج مباشرة)
    val category: String,       // الفئة العامة بعد التصنيف: فن / حيوانات / طبيعة ...إلخ
    val confidence: Float,
    val indexedAt: Long
)

package com.example.photosearch.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * قاعدة بيانات محلية بالكامل، ملفها الفعلي يعيش داخل تخزين التطبيق الخاص
 * (/data/data/com.example.photosearch/databases) — لا يمكن لأي تطبيق آخر
 * أو أي جهة خارجية الوصول إليها.
 */
@Database(entities = [ImageTagEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun imageTagDao(): ImageTagDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "photosearch_local.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
